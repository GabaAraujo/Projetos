//SCRIPT CONVERSOR LAT-LONG



        var UTM_SCALE_FACTOR = 0.9996;
        var pi = 3.14159265358979;
        var UTM_ZONE = 23; //utm_zone do brasil

        /* Ellipsoid model constants (for WGS84) */
        var sm_a = 6378137.0;
        var sm_b = 6356752.314;
        var sm_EccSquared = 6.69437999013e-03;

        function DegToRad(deg) {
            return (deg / 180.0 * pi);
        }

        function UTMtoGeo(xUTM, yUTM) {                                  
            var latlon = new Array(2);
            var x, y, zone, southhemi, Lat, Lon;
            var coords = [2];
            coords[0] = 0;
            coords[1] = 0;
            zone = UTM_ZONE;
            southhemi = true;  

            if (isNaN(parseInt(zone))) {
                console.log("Please enter a valid UTM zone in the zone field.");
                return coords;
            } 
            zone = parseFloat(zone);
            
            if ((zone < 1) || (60 < zone)) {
                console.log("The UTM zone you entered is out of range. Please enter a number in the range [1, 60].");
                return coords;
            }   
            
            if (isNaN(parseFloat(xUTM))) {
                console.log("Please enter a valid easting in the x field.");
                return coords;
            }

            // Adjust x value
            x = parseFloat(xUTM);       
            x = x / 100; // Convert from centimeters to meters
            if ((x < 167000) || (x > 8330000)) {
                console.log("Easting in the x field is out of range.");
                return coords;
            }

            if (isNaN(parseFloat(yUTM))) {
                console.log("Please enter a valid northing in the y field.");
                return coords;
            }

            // Adjust y value
            y = parseFloat(yUTM); 
            y = y / 100; // Convert from centimeters to meters
            if ((y < 0) || (y > 9999999)) {
                console.log("Northing in the y field is out of range.");
                return coords;
            }        

            UTMXYToLatLon(x, y, zone, southhemi, latlon);        
            
            // Check lat lon values are in range
            var lon = RadToDeg(latlon[1])
            if (((lon < -180)) || ((lon > 180))) {
                console.log("Calculated Longitude is out of range. Check Northing");
                return coords;
            }
            
            var lat = RadToDeg(latlon[0])
            if (((lat < -90)) || ((lat > 90))) {
                console.log("Calculated Latitude out of range. Check Easting");
                return coords;
            }

            // Add marker
            coords[0] = roundNumber(lat, 8).toString();
            coords[1] = roundNumber(lon, 8).toString();

            return coords;
        }

        function UTMXYToLatLon (x, y, zone, southhemi, latlon) {
            var cmeridian;        

            x -= 500000.0;
            x /= UTM_SCALE_FACTOR;

            if (southhemi)
                y -= 10000000.0;
                
            y /= UTM_SCALE_FACTOR;
            
            cmeridian = UTMCentralMeridian (zone);
            MapXYToLatLon (x, y, cmeridian, latlon);
            
            return;
        }

        function UTMCentralMeridian (zone) {
            var cmeridian;

            cmeridian = DegToRad (-183.0 + (zone * 6.0));

            return cmeridian;
        }

        function MapXYToLatLon (x, y, lambda0, philambda) {
            var phif, Nf, Nfpow, nuf2, ep2, tf, tf2, tf4, cf;
            var x1frac, x2frac, x3frac, x4frac, x5frac, x6frac, x7frac, x8frac;
            var x2poly, x3poly, x4poly, x5poly, x6poly, x7poly, x8poly;
            
            phif = FootpointLatitude (y);
                
            ep2 = (Math.pow (sm_a, 2.0) - Math.pow (sm_b, 2.0)) / Math.pow (sm_b, 2.0);
            
            cf = Math.cos (phif);
                
            nuf2 = ep2 * Math.pow (cf, 2.0);
                
            Nf = Math.pow (sm_a, 2.0) / (sm_b * Math.sqrt (1 + nuf2));
            Nfpow = Nf;
                
            tf = Math.tan (phif);
            tf2 = tf * tf;
            tf4 = tf2 * tf2;
            
            x1frac = 1.0 / (Nfpow * cf);
            
            Nfpow *= Nf;
            x2frac = tf / (2.0 * Nfpow);
            
            Nfpow *= Nf;
            x3frac = 1.0 / (6.0 * Nfpow * cf);
            
            Nfpow *= Nf;
            x4frac = tf / (24.0 * Nfpow);
            
            Nfpow *= Nf;
            x5frac = 1.0 / (120.0 * Nfpow * cf);
            
            Nfpow *= Nf;
            x6frac = tf / (720.0 * Nfpow);
            
            Nfpow *= Nf;
            x7frac = 1.0 / (5040.0 * Nfpow * cf);
            
            Nfpow *= Nf;
            x8frac = tf / (40320.0 * Nfpow);
            
            x2poly = -1.0 - nuf2;
            
            x3poly = -1.0 - 2 * tf2 - nuf2;
            
            x4poly = 5.0 + 3.0 * tf2 + 6.0 * nuf2 - 6.0 * tf2 * nuf2 - 3.0 * (nuf2 *nuf2) - 9.0 * tf2 * (nuf2 * nuf2);
            
            x5poly = 5.0 + 28.0 * tf2 + 24.0 * tf4 + 6.0 * nuf2 + 8.0 * tf2 * nuf2;
            
            x6poly = -61.0 - 90.0 * tf2 - 45.0 * tf4 - 107.0 * nuf2 + 162.0 * tf2 * nuf2;
            
            x7poly = -61.0 - 662.0 * tf2 - 1320.0 * tf4 - 720.0 * (tf4 * tf2);
            
            x8poly = 1385.0 + 3633.0 * tf2 + 4095.0 * tf4 + 1575 * (tf4 * tf2);
                
            philambda[0] = phif + x2frac * x2poly * (x * x) + x4frac * x4poly * Math.pow (x, 4.0) + x6frac * x6poly * Math.pow (x, 6.0) + x8frac * x8poly * Math.pow (x, 8.0);
                
            philambda[1] = lambda0 + x1frac * x + x3frac * x3poly * Math.pow (x, 3.0) + x5frac * x5poly * Math.pow (x, 5.0) + x7frac * x7poly * Math.pow (x, 7.0);
            
            return;
        }

        function FootpointLatitude (y) {
            var y_, alpha_, beta_, gamma_, delta_, epsilon_, n;
            var result;
            
            n = (sm_a - sm_b) / (sm_a + sm_b);
                
            alpha_ = ((sm_a + sm_b) / 2.0) * (1 + (Math.pow (n, 2.0) / 4) + (Math.pow (n, 4.0) / 64));
            
            y_ = y / alpha_;
            
            beta_ = (3.0 * n / 2.0) + (-27.0 * Math.pow (n, 3.0) / 32.0) + (269.0 * Math.pow (n, 5.0) / 512.0);
            
            gamma_ = (21.0 * Math.pow (n, 2.0) / 16.0) + (-55.0 * Math.pow (n, 4.0) / 32.0);
            
            delta_ = (151.0 * Math.pow (n, 3.0) / 96.0);
                
            epsilon_ = (1097.0 * Math.pow (n, 4.0) / 512.0);
                
            result = y_ + (beta_ * Math.sin (2.0 * y_)) + (gamma_ * Math.sin (4.0 * y_)) + (delta_ * Math.sin (6.0 * y_)) + (epsilon_ * Math.sin (8.0 * y_));
            
            return result;
        }

        function RadToDeg(rad) {
            return (rad * 180.0 / pi);
        }

        function roundNumber(rnum, rlength) { 
            return Math.round(rnum * Math.pow(10, rlength)) / Math.pow(10, rlength);
        }

        function convert() {
            // Example UTM values in centimeters
            //var xUTM = 61255200;
            //var yUTM = 773569300;
            
            // Convert to latitude and longitude
            var coords = UTMtoGeo(xUTM, yUTM);
            
            // Display results
            //document.getElementById('latitude').textContent = 'Latitude: ' + coords[0];
            //document.getElementById('longitude').textContent = 'Longitude: ' + coords[1];
        }
    


//script conversor LAT-LONG


function GetSignalLevel(signal) // 255-192-128-0
{
	var result;

    if(signal = '255')
    {
        result = '100%'
        return result;
    }
    if(signal = '192')
    {
        result = '75%'
        return result
    }

    if(signal = '128')
    {
        result = '50%'
        return result
    }
    if(signal = '68')
    {
        result = '25%'
        return result
    }
    if(signal = '0')
        {
            result = '0%'
            return result
        }




}








let map;
let markers = [];

function initMap() {
    // Inicializa o mapa centrado em uma localização padrão
    map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: -20.474, lng: -43.92 }, //mina aboboras = -20.15127389125591, -43.880069030688475
        zoom: 10
    });

    // Busca e atualiza o mapa com dados inicialmente e a cada 15 segundos
    fetchDataAndUpdateMap();
    setInterval(fetchDataAndUpdateMap, 15000);
}

function fetchDataAndUpdateMap() {
    const equipmentFilter = document.getElementById('equipmentFilter').value;
    const typeFilter = document.getElementById('typeFilter').value;
    const statusFilter = document.getElementById('statusFilter').value;

    fetch('https://localhost:7086/api/MinaApi/EquipmentStatus')
        .then(response => response.json())
        .then(data => {
            // Preenche os filtros com os dados recebidos
            if (document.getElementById('equipmentFilter').options.length === 1) {
                populateFilters(data);
            }

            clearMarkers();
            fetch('Cod_Aux/config-MSA-v5.xml')
                .then(response => response.text())
                .then(xmlText => {
                    const parser = new DOMParser();
                    const xmlDoc = parser.parseFromString(xmlText, "application/xml");

                    data.forEach(equipment => {
                        // Aplica os filtros
                        if ((equipmentFilter && equipment.equipamento !== equipmentFilter) ||
                            (typeFilter && equipment.tipO_EQUIPAMENTO !== typeFilter) ||
                            (statusFilter && equipment.cH_SMT_ACTIVE.toString() !== statusFilter)) {
                            return; // Se não corresponder ao filtro, pula para o próximo equipamento
                        }

                        const cd_state = equipment.nuM_ESTADO;
                        const stateGroup = Array.from(xmlDoc.getElementsByTagName("STATE_GROUP"))
                            .find(group => group.getAttribute("cd_state") === cd_state.toString());

                        const cd_eqt_image = stateGroup ? stateGroup.getAttribute("cd_eqt_image") : null;
                        const caminho_fotos = `images/${equipment.tipO_EQUIPAMENTO}.png`;

                        var coord_convertida = UTMtoGeo(equipment.latitude, equipment.longitude);

                        let latLng = new google.maps.LatLng(
                            coord_convertida[0],
                            coord_convertida[1]
                        );

                        let marker = new google.maps.Marker({
                            position: latLng,
                            map: map,
                            title: equipment.equipamento,
                            icon: {
                                url: caminho_fotos,
                                scaledSize: new google.maps.Size(40, 40) // Tamanho reduzido
                            }
                        });

                        var sinal = GetSignalLevel(equipment.sinal);

                        let infowindow = new google.maps.InfoWindow({
                            content: `<div><strong>${equipment.equipamento}</strong><br>${equipment.estado}<br>Velocidade: ${equipment.velocidade}<br>Sinal: ${sinal}<br>Data: ${new Date(equipment.datA_DO_ESTADO).toLocaleString()}<br>Tipo Equipamento: ${equipment.tipO_EQUIPAMENTO}</div>`
                        });

                        marker.addListener('click', function () {
                            infowindow.open(map, marker);
                        });

                        markers.push(marker);
                    });
                })
                .catch(error => console.error('Error fetching XML data:', error));
        })
        .catch(error => console.error('Error fetching data:', error));
}

function clearMarkers() {
    markers.forEach(marker => marker.setMap(null));
    markers = [];
}

function openTab(tabName) {
    const contents = document.querySelectorAll('.tab-content');
    contents.forEach(content => {
        content.classList.remove('active');
    });

    document.getElementById(tabName).classList.add('active');
}

function populateFilters(data) {
    const equipmentFilter = document.getElementById('equipmentFilter');
    const typeFilter = document.getElementById('typeFilter');
    
    // Preecher os filtros dinamicamente
    const equipmentSet = new Set();
    const typeSet = new Set();
    
    data.forEach(equipment => {
        equipmentSet.add(equipment.equipamento);
        typeSet.add(equipment.tipO_EQUIPAMENTO);
    });

    equipmentSet.forEach(equipment => {
        const option = document.createElement('option');
        option.value = equipment;
        option.text = equipment;
        equipmentFilter.add(option);
    });

    typeSet.forEach(type => {
        const option = document.createElement('option');
        option.value = type;
        option.text = type;
        typeFilter.add(option);
    });
}

function convertToDegrees(decimal) {
    return decimal / 1000000;
}

function clearTabContents() {
    document.querySelectorAll('.tab-pane').forEach(tab => {
        tab.innerHTML = '';
    });
}

$(document).ready(function() {
    const equipmentMapping = {
        'Caminhão Munck': 'Caminhão',
        'Escavadeira': 'Escavadeira',
        'Carregadeira': 'Carregadeira',
        'Mini Carregadeira': 'Carregadeira',
        'Trator de Pneus': 'Trator',
        'Trator de Esteiras': 'Trator',
        'Empilhadeira': 'Empilhadeira',
        'Rompedor': 'Rompedor',
        'Motoniveladora': 'Motoniveladora',
        'Perfuratriz': 'Perfuratriz',
        'Caminhão': 'Caminhão',
        'Caminhão Comboio': 'Caminhão',
        'Caminhão Tanque': 'Caminhão',
        'Caminhão Pipa': 'Caminhão',
        'Caminhão Toco': 'Caminhão',
        'Balança': 'Balança'
    };

    const apiUrl = 'https://localhost:7086/api/MinaApi/EquipmentStatus'; // Insira a URL da API aqui

    // Função para atualizar a lista de equipamentos
    function updateEquipmentList(equipmentType) {
        $.getJSON(apiUrl, function(data) {
            let equipmentList = $('#equipment-list');
            equipmentList.empty();
            data.forEach(equipment => {
                let mappedType = equipmentMapping[equipment.tipO_EQUIPAMENTO];
                if (mappedType === equipmentType || equipmentType === "Todos") {
                    let equipmentHtml = `
                        <div class="image-item">
                            <img src="images/${mappedType}.png" class="small-img rounded" alt="${mappedType}" data-lat="${equipment.latitude}" data-lng="${equipment.longitude}">
                            <div class="image-text">${equipment.equipamento}</div>
                        </div>
                    `;
                    equipmentList.append(equipmentHtml);
                }
            });

            // Adiciona evento de clique às imagens
            $('.image-item img').on('click', function() {
                let lat = $(this).data('lat');
                let lng = $(this).data('lng');
                let coord_convertida = UTMtoGeo(lat, lng);

                let latLng = new google.maps.LatLng(
                    coord_convertida[0],
                    coord_convertida[1]
                );

                map.setCenter(latLng);
                map.setZoom(15); // Ajuste o nível de zoom conforme necessário
            });
        });
    }

    // Inicializar com os caminhões
    updateEquipmentList('Caminhão');

    // Função para definir a aba ativa
    function setActiveTab(tabId) {
        $('.nav-link').removeClass('active');
        $(`#${tabId}`).addClass('active');
    }

    // Event listeners para os botões de filtro
    $('#caminhao-tab').on('click', function() { setActiveTab('caminhao-tab'); updateEquipmentList('Caminhão'); });
    $('#escavadeira-tab').on('click', function() { setActiveTab('escavadeira-tab'); updateEquipmentList('Escavadeira'); });
    $('#carregadeira-tab').on('click', function() { setActiveTab('carregadeira-tab'); updateEquipmentList('Carregadeira'); });
    $('#trator-tab').on('click', function() { setActiveTab('trator-tab'); updateEquipmentList('Trator'); });
    $('#empilhadeira-tab').on('click', function() { setActiveTab('empilhadeira-tab'); updateEquipmentList('Empilhadeira'); });
    $('#rompedor-tab').on('click', function() { setActiveTab('rompedor-tab'); updateEquipmentList('Rompedor'); });
    $('#motoniveladora-tab').on('click', function() { setActiveTab('motoniveladora-tab'); updateEquipmentList('Motoniveladora'); });
    $('#perfuratriz-tab').on('click', function() { setActiveTab('perfuratriz-tab'); updateEquipmentList('Perfuratriz'); });
});

window.onload = initMap;