document.addEventListener("DOMContentLoaded", function () {
  // Dados de exemplo
  const productionData = [37058, 39978, 37817, 37869, 45961, 34612, 36959, 35201];
  const energyProduction = 11153;
  const gasProduction = 108554;
  const oilProduction = 185748;

  // Configuração do gráfico de Níveis de Produção
  const productionOptions = {
      chart: {
          type: 'line',
          height: 350
      },
      series: [{
          name: 'Production',
          data: productionData
      }],
      xaxis: {
          categories: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'jun', 'jul', 'Ago','Set','Out','Nov','Dez']
      }
  };

  // Configuração dos gráficos de Gauge
  const energyOptions = {
      chart: {
          type: 'radialBar',
          height: 350
      },
      series: [energyProduction],
      labels: ['Energy Production'],
      plotOptions: {
          radialBar: {
              dataLabels: {
                  name: {
                      fontSize: '22px'
                  },
                  value: {
                      fontSize: '16px'
                  },
                  total: {
                      show: true,
                      label: 'Total',
                      formatter: function () {
                          return energyProduction;
                      }
                  }
              }
          }
      }
  };

  const gasOptions = {
      chart: {
          type: 'radialBar',
          height: 350
      },
      series: [gasProduction],
      labels: ['Gas Production'],
      plotOptions: {
          radialBar: {
              dataLabels: {
                  name: {
                      fontSize: '22px'
                  },
                  value: {
                      fontSize: '16px'
                  },
                  total: {
                      show: true,
                      label: 'Total',
                      formatter: function () {
                          return gasProduction;
                      }
                  }
              }
          }
      }
  };

  const oilOptions = {
      chart: {
          type: 'radialBar',
          height: 350
      },
      series: [oilProduction],
      labels: ['Oil Production'],
      plotOptions: {
          radialBar: {
              dataLabels: {
                  name: {
                      fontSize: '22px'
                  },
                  value: {
                      fontSize: '16px'
                  },
                  total: {
                      show: true,
                      label: 'Total',
                      formatter: function () {
                          return oilProduction;
                      }
                  }
              }
          }
      }
  };

  // Renderizando os gráficos
  const productionChart = new ApexCharts(document.querySelector("#production-levels"), productionOptions);
  productionChart.render();

  const energyChart = new ApexCharts(document.querySelector("#energy-production"), energyOptions);
  energyChart.render();

  const gasChart = new ApexCharts(document.querySelector("#gas-production"), gasOptions);
  gasChart.render();

  const oilChart = new ApexCharts(document.querySelector("#oil-production"), oilOptions);
  oilChart.render();
});
