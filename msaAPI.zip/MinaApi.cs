﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ApiMina3
{
    [Table("sm_log_cycle", Schema = "SMO")]
    public class sm_log_cycle  //nome da tabela
    {
        [Key]
        public decimal? CD_CYCLE { get; set; }
        public DateTime DT_END { get; set; }
        public double? QT_MASS { get; set; }
        public decimal? CH_MATERIAL { get; set; }

        public decimal? CD_LITH { get; set; }
    }

    [Table("AUX_EQT_MINE_PROD", Schema = "SMO")]
    public class aux_eqt_mine_prod
    {
        public DateTime DT_EVENT { get; set; }
        public decimal? CD_UNLOAD { get; set; }
        public decimal? CD_LOAD { get; set; }
        public decimal? CD_EQT { get; set; }
        public decimal? CD_LOAD_EQT { get; set; }
        public decimal? CH_MATERIAL { get; set; }
        public decimal? CD_MOV_TYPE { get; set; }
        public decimal? CD_LITH { get; set; }
        public decimal? CD_LOG_TURN { get; set; }
        public decimal? QT_MASS { get; set; }
        public decimal? QT_VOLUME { get; set; }
        public decimal? NU_TRIPS { get; set; }
        public decimal? NU_WEIGH { get; set; }
        public decimal? QT_DISTANCE { get; set; }
        public decimal? CD_UO { get; set; }
    }

    [Table("SM_LITH_TYPE", Schema = "SMO")]
    public class sm_lith_type  //nome da tabela
    {
        [Key]
        public decimal? CD_LITH_TYPE { get; set; }
        public string? NM_LITH_TYPE { get; set; }
        public decimal? TP_LITH_TYPE { get; set; }
        public double? QT_DENSITY { get; set; }
    }

    [Table("SM_MINE_ENTITY", Schema = "SMO")]
    public class sm_mine_entity  //nome da tabela
    {
        [Key]
        public decimal? CD_ENTITY { get; set; }
        public string? NM_ENTITY { get; set; }
    }

    public class CustomResponse
    {
        public string Integracao { get; set; } = "SMARTMINE";
        public string Operacao { get; set; } = "REGISTRO_PRODUCAO";
        public string Centro { get; set; } = "SA20";
        public string DataHoraRegistro { get; set; } // Output name for DT_EVENT
        public string DataHoraEnvio { get; set; } // New field for current datetime
        public string Produto { get; set; } // Output name for NM_LITH_TYPE
        public string Origem { get; set; } // Output name for NM_ENTITY
        public decimal? Valor { get; set; } // Output name for QT_MASS
    }


    public class CustomResponseService
    {
        public string MapProduto(decimal? chMaterial, decimal? cdLith, string produto)
        {
            if (chMaterial == 1)
            {
                return "ISM_PROD_ROM";
            }
            else if (chMaterial == 2)
            {
                return "ISM_PROD_ESTERIL";
            }
            else if (cdLith == 13)
            {
                return "ISM_PROD_REJEITO_GROSSO";
            }
            return produto; // Return the original name if no match
        }

        public string MapOrigem(string origem)
        {
            return origem.Contains("812") ? "ISM_CAVA_812" : "ISM_CAVA_CENTRAL";
        }
    }





}
    

