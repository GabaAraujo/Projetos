﻿using ApiMina3;
using ApiMina3.Models;
using Microsoft.EntityFrameworkCore;

public class TodoContext : DbContext
{
    public TodoContext(DbContextOptions<TodoContext> options) : base(options)
    {
    }

    public DbSet<sm_log_cycle> Sm_log_cycles { get; set; }
    public DbSet<aux_eqt_mine_prod> Aux_Eqt_Mine_Prod { get; set; }
    public DbSet<sm_lith_type> Sm_lith_type { get; set; }
    public DbSet<sm_mine_entity> Sm_mine_entity { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
            optionsBuilder.UseSqlServer("DefaultConnection", options =>
            {
                options.EnableRetryOnFailure(
                    maxRetryCount: 5, // Número máximo de tentativas
                    maxRetryDelay: TimeSpan.FromSeconds(30), // Tempo máximo de atraso entre tentativas
                    errorNumbersToAdd: null // Lista de números de erro adicionais a considerar como transitórios
                );
            });
        }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Mapeamento da entidade sm_log_cycle, se necessário
        modelBuilder.Entity<sm_log_cycle>().ToTable("sm_log_cycle", schema: "SMO");

        modelBuilder.Entity<aux_eqt_mine_prod>().HasNoKey();

        base.OnModelCreating(modelBuilder);
    }
}
