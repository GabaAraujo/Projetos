﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ApiMina3.Models
{
    [Table("SMO.sm_log_cycle", Schema = "your_schema_name")]
  
    public class Sm_log_cycle
    {
        [Key]
        public decimal? CD_CYCLE { get; set; }

        public DateTime DT_END { get; set; }

        public Double? QT_MASS { get; set; }


        public decimal? CH_MATERIAL { get; set; }

        public decimal? CD_LITH { get; set; }


    }

    [Table("AUX_EQT_MINE_PROD", Schema = "SMO")]
    public class Aux_eqt_mine_prod
    {
        public DateTime DT_EVENT { get; set; }
        public decimal? CD_UNLOAD { get; set; }

        public decimal? CD_LOAD { get; set; }

        public decimal? CD_EQT { get; set; }


        public decimal? CD_LOAD_EQT { get; set; }


        public decimal? CH_MATERIAL { get; set; }

        public decimal? CD_MOV_TYPE { get; set; }

        public decimal? CD_LITH { get; set; }

        public decimal? CD_LOG_TURN { get; set; }

        public decimal? QT_MASS { get; set; }

        public decimal? QT_VOLUME { get; set; }

        public decimal? NU_TRIPS { get; set; }

        public decimal? NU_WEIGH { get; set; }

        public decimal? QT_DISTANCE { get; set; }

        public decimal? CD_UO { get; set; }
    }


    [Table("SM_LITH_TYPE", Schema = "SMO")]
    public class Sm_lith_type  //nome da tabela
    {

        [Key]
        public decimal? CD_LITH_TYPE { get; set; }



        public string? NM_LITH_TYPE { get; set; }

        public decimal? TP_LITH_TYPE { get; set; }


        public double? QT_DENSITY { get; set; }

      //  public decimal? DT_DELETE { get; set; }





    }



    [Table("SM_MINE_ENTITY", Schema = "SMO")]
    public class Sm_mine_entity  //nome da tabela
    {

        [Key]
        public decimal? CD_ENTITY { get; set; }

        public string? NM_ENTITY { get; set; }

    }














}
