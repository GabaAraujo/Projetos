﻿using ApiMina3.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Cors;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using System.Linq;

namespace ApiMina3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("MyPolicy")]
    public class MinaApiController : ControllerBase
    {
        private readonly TodoContext _context;
        private readonly CustomResponseService _responseService;

        public MinaApiController(TodoContext context)
        {
            _context = context;
            _responseService = new CustomResponseService();
        }

        [HttpGet("SMO.aux_eqt_mine_prod")]
        public async Task<ActionResult<IEnumerable<CustomResponse>>> GetAuxEqtMineProd([FromQuery] int limit = 1000)
        {
            try
            {
                limit = (limit > 1000) ? 1000 : limit;

                var data = await (from aemp in _context.Aux_Eqt_Mine_Prod
                                  join slt in _context.Sm_lith_type on aemp.CH_MATERIAL equals slt.CD_LITH_TYPE
                                  join sme in _context.Sm_mine_entity on aemp.CD_LOAD equals sme.CD_ENTITY
                                  orderby aemp.DT_EVENT descending
                                  select new
                                  {
                                      aemp.DT_EVENT,
                                      slt.NM_LITH_TYPE,
                                      sme.NM_ENTITY,
                                      aemp.QT_MASS,
                                      aemp.CH_MATERIAL,
                                      aemp.CD_LITH
                                  }).Take(limit).ToListAsync();

                // Group data by hour, product, and origin
                var groupedData = data
                    .GroupBy(d => new
                    {
                        // Group by hour interval
                        HourInterval = new DateTime(d.DT_EVENT.Year, d.DT_EVENT.Month, d.DT_EVENT.Day, d.DT_EVENT.Hour, 0, 0),
                        Produto = _responseService.MapProduto(d.CH_MATERIAL, d.CD_LITH, d.NM_LITH_TYPE),
                        Origem = _responseService.MapOrigem(d.NM_ENTITY)
                    })
                    .Select(g => new CustomResponse
                    {
                        DataHoraRegistro = g.Key.HourInterval.ToString("yyyy-MM-dd HH:00:00"), // Format to hour precision
                        DataHoraEnvio = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), // Current datetime
                        Produto = g.Key.Produto,
                        Origem = g.Key.Origem,
                        Valor = g.Sum(x => x.QT_MASS) ?? 0 // Sum the QT_MASS values
                    })
                    .ToList();

                return Ok(groupedData);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Erro ao obter itens: {ex.Message}");
            }
        }

    }
}
