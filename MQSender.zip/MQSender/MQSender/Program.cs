﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Net.Http;
using System.Threading.Tasks;
using IBM.WMQ;
using Newtonsoft.Json.Linq;
using System.Configuration;
using System.Linq;

namespace MQSender
{
    class Program
    {
        static async Task Main(string[] args)
        {
            // Valores fornecidos para a fila MQ
            string queueName = ConfigurationManager.AppSettings["queueName"];
            string channel = ConfigurationManager.AppSettings["MQChannel"];
            string queueManager = ConfigurationManager.AppSettings["MQQueueManager"];
            string hostName = ConfigurationManager.AppSettings["MQHostName"];
            int port = int.Parse(ConfigurationManager.AppSettings["MQPort"]);

            var properties = new Hashtable
            {
                { MQC.HOST_NAME_PROPERTY, hostName },
                { MQC.PORT_PROPERTY, port },
                { MQC.CHANNEL_PROPERTY, channel },
            };

            bool messageSent = false;
            while (!messageSent)
            {
                IBM.WMQ.MQQueueManager queueManagerObj = null;
                IBM.WMQ.MQQueue queue = null;
                Tuple<string, bool> response;

                try
                {
                    // Fetch data from API
                    string apiUrl = ConfigurationManager.AppSettings["ApiURL"];
                    string jsonResponse = await FetchDataFromApi(apiUrl);

                    // Deserialize JSON to a list of objects
                    JArray jsonArray = JArray.Parse(jsonResponse);

                    // Get the start and end of the previous hour
                    DateTime now = DateTime.Now;
                    DateTime previousHourStart = now.AddHours(-1).Date.AddHours(now.Hour - 1);
                    DateTime previousHourEnd = previousHourStart.AddHours(1);

                    // Filter the JSON data for the previous hour
                    var filteredJsonArray = jsonArray
                        .Where(item =>
                        {
                            DateTime dataHoraRegistro = DateTime.Parse(item["dataHoraRegistro"].ToString());
                            return dataHoraRegistro >= previousHourStart && dataHoraRegistro < previousHourEnd;
                        });

                    // Cria conexão com o MQ
                    queueManagerObj = new IBM.WMQ.MQQueueManager(queueManager, properties);

                    // Abre a fila para mensagens
                    queue = queueManagerObj.AccessQueue(queueName, MQC.MQOO_OUTPUT);

                    foreach (var item in filteredJsonArray)
                    {
                        // Cria mensagem e coloca na fila
                        var message = new IBM.WMQ.MQMessage
                        {
                            Format = MQC.MQFMT_STRING,
                            CharacterSet = 1208 // UTF-8
                        };

                        message.WriteString(item.ToString(Newtonsoft.Json.Formatting.None));
                        queue.Put(message);

                        response = new Tuple<string, bool>("Mensagem enviada para o MES", true);
                        Console.WriteLine(response.Item1);

                        // Registro no banco de dados
                        RegistrarRequisicaoNoBanco(queueName, item.ToString(Newtonsoft.Json.Formatting.None), response.Item2, response.Item1);
                    }

                    // Set messageSent to true to exit the loop
                    messageSent = true;
                }
                catch (Exception ex)
                {
                    response = new Tuple<string, bool>("Erro ao enviar para o MES: " + ex.Message, false);
                    Console.WriteLine(response.Item1);

                    // Registro no banco de dados
                    RegistrarRequisicaoNoBanco(queueName, "", response.Item2, response.Item1);

                    // Wait for 15 seconds before retrying
                    await Task.Delay(15000);
                }
                finally
                {
                    // Disconecta todas as conexões
                    if (queue != null)
                        queue.Close();
                    if (queueManagerObj != null)
                        queueManagerObj.Disconnect();
                }
            }
        }

        static async Task<string> FetchDataFromApi(string apiUrl)
        {
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(apiUrl);
                response.EnsureSuccessStatusCode();
                return await response.Content.ReadAsStringAsync();
            }
        }

        static void RegistrarRequisicaoNoBanco(string fila, string valor, bool resultadoRequest, string response)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            string query = "INSERT INTO smo.TabelaIntegracao (fila, dataHoraRegistro, valor, resultado_request, response) VALUES (@fila, @dataHoraRegistro, @valor, @resultadoRequest, @response)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@fila", fila);
                command.Parameters.AddWithValue("@dataHoraRegistro", DateTime.Now);
                command.Parameters.AddWithValue("@valor", valor);
                command.Parameters.AddWithValue("@resultadoRequest", resultadoRequest);
                command.Parameters.AddWithValue("@response", response);

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }
    }
}
