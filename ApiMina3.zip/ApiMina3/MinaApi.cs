﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ApiMina3
{
    [Table("sm_log_cycle", Schema = "SMO")]
    public class sm_log_cycle
    {
        [Key]
        public decimal? CD_CYCLE { get; set; }
        public DateTime DT_END { get; set; }
        public double? QT_MASS { get; set; }
        public decimal? CH_MATERIAL { get; set; }
    }

    [Table("aux_eqt_allocation", Schema = "SMO")]
    public class aux_eqt_allocation
    {
        [Key]
        public decimal? CD_EQT { get; set; }

        public string? CD_LOAD {  get; set; } //onde foi carregado

        public string? CD_UNLOAD { get; set; } //onde vai ser descarregado


        public DateTime? DT_START {  get; set; }  //tempo no momento q foi carregado

        public DateTime? DT_END { get; set; } //tempo no momento q  foi descarregado

        public decimal? CD_LITH { get; set; } //
    
        public decimal? CD_LITH_TYPE { get; set; }



    }

    [Table("sm_mine_entity", Schema = "SMO")]
    public class sm_mine_entity
    {
        [Key]

        public decimal? CD_ENTITY { get; set; }

        public decimal? CD_MINE { get; set; }

        public decimal? CD_ENTITY_TYPE { get; set; }

        public decimal? CD_PIT { get; set; }

        public string? NM_ENTITY { get; set; }


    }


    [Table("sm_equipment", Schema = "SMO")]
    public class sm_equipment
    {
        [Key]
        public decimal? CD_EQT { get; set; }
        public string? NM_EQT { get; set; }
        public decimal? CH_SMT_ACTIVE { get; set; }

        public decimal? CD_EQT_STATE { get; set; }


        public DateTime? DT_INSERT { get; set; }
        public DateTime? DT_DELETE { get; set; }
    }

    [Table("sm_log_status", Schema = "SMO")]
    public class sm_log_status
    {
        [Key]
        public decimal? CD_LOG_STATUS { get; set; }
        public decimal? NU_SIGNAL { get; set; }
        public decimal? NU_SPEED { get; set; }
        public DateTime? DT_EVENT { get; set; }
        public decimal? NU_X { get; set; }
        public decimal? NU_Y { get; set; }
    }

    [Table("sm_view_states", Schema = "SMO")]
    public class sm_view_states
    {
        [Key]
        public decimal? CD_EQT_STATE { get; set; }
        public string? NM_SHORT { get; set; }


        public decimal? CD_STATE_1 { get; set; }
        public decimal? CD_STATE_2 { get; set; }
        public decimal? CD_STATE_3 { get; set; }
    }

    [Table("sm_eqt_images", Schema = "SMO")]
    public class sm_eqt_images
    {
        [Key]
        public decimal? CD_EQT_IMAGE { get; set; }
        public string? BL_IMAGE { get; set; }
    }

    [Table("SM_MODEL_EQT", Schema = "SMO")]
    public class sm_model_eqt
    {
        [Key]
        public decimal? CD_MODEL_EQT { get; set; }
        public string? NM_MODEL { get; set; }
        public decimal? CD_GROUP_IMAGE { get; set; }
    }



    [Table("SM_PROD_FLOW", Schema = "SMO")]
    public class sm_prod_flow
    {
        [Key]
        public decimal CD_PROD_FLOW { get; set; }

        public decimal? CD_PROD_FLOW_PLAN_ITEMS { get; set; }
        public decimal? CD_ORIGIN { get; set; }
        public decimal? CD_TARGET { get; set; }
        public decimal? CD_OPT_TARGET { get; set; }
        public DateTime? DT_START { get; set; }
        public DateTime? DT_START_PARTIAL_PROD { get; set; }
        public DateTime? DT_END { get; set; }
        public decimal? QT_PROD_PREV { get; set; }
        public string? TP_PARTIAL_PROD_SHOW { get; set; }
        public bool? CH_ACTIVE { get; set; }
        public bool? CH_OPTIMIZATION { get; set; }
        public bool? CH_AUTO_DISPATCH { get; set; }
        public bool? CH_PROD_HARD_RESTRICTION { get; set; }
        public bool? CH_PLANNED_FLOW { get; set; }
        public decimal? CD_CONJUGATE_FLOW { get; set; }
        public decimal? CD_MOVEMENT_REASON { get; set; }
        public decimal? QT_PROD_DIRECT_FEED { get; set; }
        public string? TP_ASSIGNED_MARKERS { get; set; }
        public string? TP_PROD_FLOW { get; set; }
    }

 



}
