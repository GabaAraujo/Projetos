using Microsoft.EntityFrameworkCore;
using ApiMina3.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace ApiMina3
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Conex�o com o banco de dados
            string connString = builder.Configuration.GetConnectionString("DefaultConnection");
            builder.Services.AddDbContext<TodoContext>(options =>
            {
                options.UseSqlServer(connString, sqlServerOptions =>
                {
                    sqlServerOptions.EnableRetryOnFailure(
                        maxRetryCount: 5, // N�mero m�ximo de tentativas
                        maxRetryDelay: TimeSpan.FromSeconds(30), // Tempo m�ximo de atraso entre tentativas
                        errorNumbersToAdd: null // Lista de n�meros de erro adicionais a considerar como transit�rios
                    );
                });
            });

            // Adicionar servi�os ao cont�iner
            builder.Services.AddControllers();

            // Configurar Swagger
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            // Configurar CORS
            builder.Services.AddCors(options => {
                options.AddPolicy(name: "MyPolicy",
                    policy =>
                    {
                        policy.WithOrigins("http://127.0.0.1:5500").AllowAnyHeader().AllowAnyMethod();
                    });
            });

            var app = builder.Build();

            // Configurar o pipeline de solicita��o HTTP
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "ApiMina3 v1");
            });

            // Configurar redirecionamento HTTPS
            var httpsPort = builder.Configuration.GetValue<int>("https_port");
            if (httpsPort > 0)
            {
                app.UseHttpsRedirection();
            }

            app.UseAuthorization();

            app.UseCors("MyPolicy");

            app.MapControllers();

            app.Run();
        }
    }
}
