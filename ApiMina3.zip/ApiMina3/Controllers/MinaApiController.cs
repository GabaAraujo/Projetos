﻿using ApiMina3.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Cors;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiMina3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("MyPolicy")]
    public class MinaApiController : ControllerBase
    {
        private readonly TodoContext _context;

        public MinaApiController(TodoContext context)
        {
            _context = context;
        }

        // GET: api/MinaApi/EquipmentStatus
        [HttpGet("EquipmentStatus")]
        public async Task<ActionResult<IEnumerable<EquipmentStatus>>> GetEquipmentStatus()
        {
            var query = @"
                        SELECT
                     SE.NM_EQT AS EQUIPAMENTO,
	                 SM.NM_MODEL AS MODELO,
	                 SVS.CD_EQT_STATE AS NUM_ESTADO,
                     SVS.NM_SHORT AS ESTADO,    
                     SLS.NU_X AS LATITUDE,
                     SLS.NU_Y AS LONGITUDE,
                     SLS.NU_SPEED AS VELOCIDADE,
                     SLS.NU_SIGNAL AS SINAL,
                     SE.CH_SMT_ACTIVE,
                     SLS.DT_EVENT AS DATA_DO_ESTADO,
	                 SGI.NM_GROUP_IMAGE AS TIPO_EQUIPAMENTO
                 FROM SMO.SM_EQUIPMENT SE
                 INNER JOIN SMO.SM_LOG_STATUS SLS ON SE.CD_EQT = SLS.CD_EQT
                 INNER JOIN SMO.SM_VIEW_STATES SVS ON SLS.CD_EQT_STATE = SVS.CD_EQT_STATE
                 INNER JOIN SMO.SM_MODEL_EQT SM ON  SM.CD_MODEL_EQT = SE.CD_MODEL_EQT
                 INNER JOIN SMO.SM_GROUP_IMAGE AS SGI ON SM.CD_GROUP_IMAGE = SGI.CD_GROUP_IMAGE";

            var equipmentStatus = await _context.EquipmentStatuses
                .FromSqlRaw(query)
                .ToListAsync();

            return equipmentStatus;
        }




        [HttpGet("EquipmentAllocation")]
        public async Task<ActionResult<IEnumerable<EquipmentAllocationDto>>> GetEquipmentAllocation()
        {
            var query = @"
    WITH RecentAllocations AS (
        SELECT
            CD_EQT,
            MAX(DT_END) AS RECENT_DT_END
        FROM SMO.aux_eqt_allocation
        GROUP BY CD_EQT
    )

    SELECT
        ae.CD_EQT,
        ae.DT_START,
        ae.DT_END,
        ae.CD_LOAD,
        ae.CD_UNLOAD,
        se.NM_EQT,
        sm.NM_MODEL AS MODELO,
        sme.NM_ENTITY AS LOCAL,
        sgi.NM_GROUP_IMAGE AS TIPO_EQUIPAMENTO
    FROM SMO.aux_eqt_allocation ae
    INNER JOIN RecentAllocations ra ON ae.CD_EQT = ra.CD_EQT AND ae.DT_END = ra.RECENT_DT_END
    INNER JOIN SMO.SM_EQUIPMENT se ON ae.CD_EQT = se.CD_EQT
    INNER JOIN SMO.SM_MINE_ENTITY sme ON ae.CD_LOAD = sme.CD_ENTITY
    LEFT JOIN SMO.SM_MODEL_EQT sm ON se.CD_MODEL_EQT = sm.CD_MODEL_EQT
    LEFT JOIN SMO.SM_GROUP_IMAGE sgi ON sm.CD_GROUP_IMAGE = sgi.CD_GROUP_IMAGE";

            var equipmentAllocation = await _context.EquipmentAllocationDto
                .FromSqlRaw(query)
                .ToListAsync();

            return equipmentAllocation;
        }





        // GET: api/MinaApi/EquipmentTransport
        [HttpGet("EquipmentTransport")]
        public async Task<ActionResult<IEnumerable<EquipmentTransportDto>>> GetEquipmentTransport()
        {
            var query = @"
                WITH PossibleStates AS (
                    SELECT 1 AS CD_STATE_1, 'Atrasos Operacionais' AS TIPO
                    UNION ALL
                    SELECT 4, 'Impedimentos Operacionais'
                    UNION ALL
                    SELECT 5, 'M. Corretiva'
                    UNION ALL
                    SELECT 6, 'M. Preventiva'
                    UNION ALL
                    SELECT 7, 'Horas Ociosas'
                    UNION ALL
                    SELECT 10, 'Serviço Auxiliar'
                    UNION ALL
                    SELECT 23, 'Não Programado'
                    UNION ALL
                    SELECT 24, 'Operando'
                )
                SELECT 
                    COALESCE(COUNT(SE.CD_EQT), 0) AS QTD,
                    PS.TIPO
                FROM PossibleStates PS
                LEFT JOIN smo.SM_VIEW_STATES SVS ON PS.CD_STATE_1 = SVS.CD_STATE_1
                LEFT JOIN smo.SM_EQUIPMENT SE ON SE.CD_EQT_STATE = SVS.CD_EQT_STATE 
                    AND SE.DT_DELETE IS NULL 
                    AND SE.TP_CLASSTYPE = 1
                GROUP BY PS.TIPO
                ORDER BY PS.TIPO";

            var equipmentTransport = await _context.Set<EquipmentTransportDto>()
                .FromSqlRaw(query)
                .ToListAsync();

            return Ok(equipmentTransport);
        }

        // GET: api/MinaApi/EquipamentoAuxiliar
        [HttpGet("EquipamentoAuxiliar")]
        public async Task<ActionResult<IEnumerable<EquipamentoAuxiliarDto>>> GetEquipamentoAuxiliar()
        {
            var query = @"
                SELECT
                    COALESCE(COUNT(SE.CD_EQT), 0) AS QTD,
                    CASE 
                        WHEN SVS.CD_STATE_1 = 7 THEN 'Horas Ociosas'
                        WHEN SVS.CD_STATE_1 = 1 THEN 'Atrasos Operacionais'
                        WHEN SVS.CD_STATE_1 = 24 THEN 'Operando'
                        WHEN SVS.CD_STATE_1 = 4 THEN 'Impedimentos Operacionais'
                        WHEN SVS.CD_STATE_1 = 5 THEN 'M. Corretiva'
                        WHEN SVS.CD_STATE_1 = 6 THEN 'M. Preventiva'
                        WHEN SVS.CD_STATE_1 = 10 THEN 'Serviço Auxiliar'
                        WHEN SVS.CD_STATE_1 = 23 THEN 'Não Programado'
                        ELSE 'Desconhecido'
                    END AS TIPO
                FROM smo.SM_EQUIPMENT SE
                INNER JOIN smo.SM_VIEW_STATES SVS ON SE.CD_EQT_STATE = SVS.CD_EQT_STATE
                WHERE 
                    SE.DT_DELETE IS NULL
                    AND SE.TP_CLASSTYPE = 3
                GROUP BY SVS.CD_STATE_1
                ORDER BY TIPO";

            var equipmentAuxiliar = await _context.EquipamentoAuxiliarDto
                .FromSqlRaw(query)
                .ToListAsync();

            var possibleStates = new Dictionary<int, string>
            {
                { 7, "Horas Ociosas" },
                { 1, "Atrasos Operacionais" },
                { 24, "Operando" },
                { 4, "Impedimentos Operacionais" },
                { 5, "M. Corretiva" },
                { 6, "M. Preventiva" },
                { 10, "Serviço Auxiliar" },
                { 23, "Não Programado" }
            };

            foreach (var state in possibleStates)
            {
                if (!equipmentAuxiliar.Any(r => r.TIPO == state.Value))
                {
                    equipmentAuxiliar.Add(new EquipamentoAuxiliarDto { QTD = 0, TIPO = state.Value });
                }
            }

            return Ok(equipmentAuxiliar.OrderBy(r => r.TIPO));
        }

        // GET: api/MinaApi/EquipamentoCarga
        [HttpGet("EquipamentoCarga")]
        public async Task<ActionResult<IEnumerable<EquipamentoCargaDto>>> GetEquipamentoCarga()
        {
            var query = @"
                SELECT
                    COALESCE(COUNT(SE.CD_EQT), 0) AS QTD,
                    CASE 
                        WHEN SVS.CD_STATE_1 = 7 THEN 'Horas Ociosas'
                        WHEN SVS.CD_STATE_1 = 1 THEN 'Atrasos Operacionais'
                        WHEN SVS.CD_STATE_1 = 24 THEN 'Operando'
                        WHEN SVS.CD_STATE_1 = 4 THEN 'Impedimentos Operacionais'
                        WHEN SVS.CD_STATE_1 = 5 THEN 'M. Corretiva'
                        WHEN SVS.CD_STATE_1 = 6 THEN 'M. Preventiva'
                        WHEN SVS.CD_STATE_1 = 10 THEN 'Serviço Auxiliar'
                        WHEN SVS.CD_STATE_1 = 23 THEN 'Não Programado'
                        ELSE 'Desconhecido'
                    END AS TIPO
                FROM smo.SM_EQUIPMENT SE
                INNER JOIN smo.SM_VIEW_STATES SVS ON SE.CD_EQT_STATE = SVS.CD_EQT_STATE
                WHERE 
                    SE.DT_DELETE IS NULL
                    AND SE.TP_CLASSTYPE = 2
                GROUP BY SVS.CD_STATE_1
                ORDER BY TIPO";

            var equipmentCarga = await _context.EquipamentoCargaDto
                .FromSqlRaw(query)
                .ToListAsync();

            var possibleStates = new Dictionary<int, string>
            {
                { 7, "Horas Ociosas" },
                { 1, "Atrasos Operacionais" },
                { 24, "Operando" },
                { 4, "Impedimentos Operacionais" },
                { 5, "M. Corretiva" },
                { 6, "M. Preventiva" },
                { 10, "Serviço Auxiliar" },
                { 23, "Não Programado" }
            };

            foreach (var state in possibleStates)
            {
                if (!equipmentCarga.Any(r => r.TIPO == state.Value))
                {
                    equipmentCarga.Add(new EquipamentoCargaDto { QTD = 0, TIPO = state.Value });
                }
            }

            return Ok(equipmentCarga.OrderBy(r => r.TIPO));
        }

        // GET: api/MinaApi/EquipamentoManutencao
        [HttpGet("EquipamentoManutencao")]
        public async Task<ActionResult<IEnumerable<EquipamentoManutencaoDto>>> GetEquipamentoManutencao()
        {
            var query = @"
                SELECT
                    COALESCE(COUNT(SE.CD_EQT), 0) AS QTD,
                    CASE 
                        WHEN SVS.CD_STATE_1 = 7 THEN 'Horas Ociosas'
                        WHEN SVS.CD_STATE_1 = 1 THEN 'Atrasos Operacionais'
                        WHEN SVS.CD_STATE_1 = 24 THEN 'Operando'
                        WHEN SVS.CD_STATE_1 = 4 THEN 'Impedimentos Operacionais'
                        WHEN SVS.CD_STATE_1 = 5 THEN 'M. Corretiva'
                        WHEN SVS.CD_STATE_1 = 6 THEN 'M. Preventiva'
                        WHEN SVS.CD_STATE_1 = 10 THEN 'Serviço Auxiliar'
                        WHEN SVS.CD_STATE_1 = 23 THEN 'Não Programado'
                        ELSE 'Desconhecido'
                    END AS TIPO
                FROM smo.SM_EQUIPMENT SE
                INNER JOIN smo.SM_VIEW_STATES SVS ON SE.CD_EQT_STATE = SVS.CD_EQT_STATE
                WHERE 
                    SE.DT_DELETE IS NULL
                    AND SE.TP_CLASSTYPE = 4
                GROUP BY SVS.CD_STATE_1
                ORDER BY TIPO";

            var equipamentoManutencao = await _context.EquipamentoManutencaoDto
                .FromSqlRaw(query)
                .ToListAsync();

            var possibleStates = new Dictionary<int, string>
            {
                { 7, "Horas Ociosas" },
                { 1, "Atrasos Operacionais" },
                { 24, "Operando" },
                { 4, "Impedimentos Operacionais" },
                { 5, "M. Corretiva" },
                { 6, "M. Preventiva" },
                { 10, "Serviço Auxiliar" },
                { 23, "Não Programado" }
            };

            foreach (var state in possibleStates)
            {
                if (!equipamentoManutencao.Any(r => r.TIPO == state.Value))
                {
                    equipamentoManutencao.Add(new EquipamentoManutencaoDto { QTD = 0, TIPO = state.Value });
                }
            }

            return Ok(equipamentoManutencao.OrderBy(r => r.TIPO));
        }



        // GET: api/MinaApi/AlocacaoDestino
        [HttpGet("AlocacaoDestino")]
        public async Task<ActionResult<IEnumerable<AlocacaoDestinoDto>>> GetAlocacaoDestino()
        {
            var query = @"
        SELECT SME.NM_ENTITY, 
               COUNT(SDT.CD_EQT) AS QTD 
        FROM smo.SM_DISPATCH_TRUCK SDT
        JOIN smo.SM_PROD_FLOW SPF ON SDT.CD_PROD_FLOW = SPF.CD_PROD_FLOW
        JOIN smo.SM_MINE_ENTITY SME ON SPF.CD_TARGET = SME.CD_ENTITY 
        WHERE SDT.CH_DISPATCHED = 1 
        GROUP BY SME.NM_ENTITY		
        ORDER BY SME.NM_ENTITY";

            var alocacaoDestino = await _context.Set<AlocacaoDestinoDto>()
                .FromSqlRaw(query)
                .ToListAsync();

            return Ok(alocacaoDestino);
        }

        // GET: api/MinaApi/AlocacaoOrigem
        [HttpGet("AlocacaoOrigem")]
        public async Task<ActionResult<IEnumerable<AlocacaoOrigemDto>>> GetAlocacaoOrigem()
        {
            var query = @"
        SELECT SME.NM_ENTITY, 
               COUNT(SDT.CD_EQT) AS QTD 
        FROM smo.SM_DISPATCH_TRUCK SDT
        JOIN smo.SM_PROD_FLOW SPF ON SDT.CD_PROD_FLOW = SPF.CD_PROD_FLOW
        JOIN smo.SM_MINE_ENTITY SME ON SPF.CD_ORIGIN = SME.CD_ENTITY 
        WHERE SDT.CH_DISPATCHED = 1 
        GROUP BY SME.NM_ENTITY		
        ORDER BY SME.NM_ENTITY";

            var alocacaoOrigem = await _context.Set<AlocacaoOrigemDto>()
                .FromSqlRaw(query)
                .ToListAsync();

            return Ok(alocacaoOrigem);
        }



        // GET: api/MinaApi/AlocacaoMaquina
        [HttpGet("AlocacaoMaquina")]
        public async Task<ActionResult<IEnumerable<AlocacaoMaquinaDto>>> GetAlocacaoMaquina()
        {
            var query = @"
        SELECT SE.NM_EQT, 
               COUNT(SDT.CD_EQT) AS QTD 
        FROM smo.SM_DISPATCH_TRUCK SDT
        JOIN smo.SM_EQUIPMENT SE ON SE.CD_EQT = SDT.CD_LOADER
        WHERE SDT.CH_DISPATCHED = 1 
        GROUP BY SE.NM_EQT 
        ORDER BY SE.NM_EQT";

            var alocacaoMaquina = await _context.Set<AlocacaoMaquinaDto>()
                .FromSqlRaw(query)
                .ToListAsync();

            return Ok(alocacaoMaquina);
        }








    }
}
