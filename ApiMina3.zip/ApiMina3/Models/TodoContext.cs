﻿using Microsoft.EntityFrameworkCore;

namespace ApiMina3.Models
{
    public class TodoContext : DbContext
    {
        public TodoContext(DbContextOptions<TodoContext> options) : base(options)
        {
        }

        // Tabela de alocação
        public DbSet<aux_eqt_allocation> Aux_eqt_allocations { get; set; }

        // Tabela da pilha
        public DbSet<sm_mine_entity> Sm_mine_entitys { get; set; }

        public DbSet<sm_log_cycle> Sm_log_cycles { get; set; }
        public DbSet<sm_equipment> Sm_Equipment { get; set; }
        public DbSet<sm_log_status> Sm_log_status { get; set; }
        public DbSet<sm_view_states> Sm_view_states { get; set; }
        public DbSet<sm_eqt_images> Sm_eqt_images { get; set; }
        public DbSet<sm_model_eqt> Sm_model_eqt { get; set; }

        // Nova tabela
        public DbSet<sm_prod_flow> Sm_prod_flows { get; set; }

        // Esta classe é apenas para mapeamento de consulta e não uma entidade real do banco de dados
        public DbSet<EquipmentStatus> EquipmentStatuses { get; set; }

        public DbSet<EquipmentAllocationDto> EquipmentAllocationDto { get; set; }

        // CONSULTAS DA PÁGINA Equipamento
        public DbSet<EquipmentTransportDto> EquipmentTransportDtos { get; set; }

        public DbSet<EquipamentoAuxiliarDto> EquipamentoAuxiliarDto { get; set; }

        public DbSet<EquipamentoCargaDto> EquipamentoCargaDto { get; set; }

        public DbSet<EquipamentoManutencaoDto> EquipamentoManutencaoDto { get; set; }

        public DbSet<AlocacaoOrigemDto> AlocacaoOrigemDto { get; set; }

        public DbSet<AlocacaoDestinoDto> AlocacaoDestinoDto { get; set; }

        public DbSet<AlocacaoMaquinaDto> AlocacaoMaquinaDto { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Mapeamento de entidades sem chave
            modelBuilder.Entity<EquipmentStatus>().HasNoKey();
            modelBuilder.Entity<EquipmentAllocationDto>().HasNoKey();
            modelBuilder.Entity<EquipmentTransportDto>().HasNoKey();
            modelBuilder.Entity<EquipamentoAuxiliarDto>().HasNoKey();
            modelBuilder.Entity<EquipamentoCargaDto>().HasNoKey();
            modelBuilder.Entity<EquipamentoManutencaoDto>().HasNoKey();
            modelBuilder.Entity<AlocacaoOrigemDto>().HasNoKey();
            modelBuilder.Entity<AlocacaoDestinoDto>().HasNoKey();
            modelBuilder.Entity<AlocacaoMaquinaDto>().HasNoKey();
        }
    }
}
