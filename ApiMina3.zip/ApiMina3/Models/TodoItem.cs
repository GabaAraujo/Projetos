﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ApiMina3.Models
{
    [Table("sm_log_cycle", Schema = "SMO")]
    public class sm_log_cycle
    {
        [Key]
        public decimal? CD_CYCLE { get; set; }
        public DateTime DT_END { get; set; }
        public double? QT_MASS { get; set; }
        public decimal? CH_MATERIAL { get; set; }
    }



    [Table("sm_mine_entity", Schema = "SMO")]
    public class sm_mine_entity
    {
        [Key]

        public decimal? CD_ENTITY { get; set; }

        public decimal? CD_MINE { get; set; }

        public decimal? CD_ENTITY_TYPE { get; set; }

        public decimal? CD_PIT { get; set; }

        public string? NM_ENTITY { get; set; }


    }







    [Table("aux_eqt_allocation", Schema = "SMO")]
    public class aux_eqt_allocation
    {
        [Key]
        public decimal? CD_EQT { get; set; }

        public string? CD_LOAD { get; set; } //onde foi carregado

        public string? CD_UNLOAD { get; set; } //onde vai ser descarregado


        public DateTime? DT_START { get; set; }  //tempo no momento q foi carregado

        public DateTime? DT_END { get; set; } //tempo no momento q  foi descarregado

        public decimal? CD_LITH { get; set; } //

        public decimal? CD_LITH_TYPE { get; set; }



    }








    [Table("sm_equipment", Schema = "SMO")]
    public class sm_equipment
    {
        [Key]
        public decimal? CD_EQT { get; set; }
        public string? NM_EQT { get; set; }
        public decimal? CH_SMT_ACTIVE { get; set; }

        public decimal? TP_CLASSTYPE {  get; set; }

        public decimal? CD_EQT_STATE { get; set; }

        public DateTime? DT_INSERT { get; set; }
        public DateTime? DT_DELETE {  get; set; }


    }

    [Table("sm_log_status", Schema = "SMO")]
    public class sm_log_status
    {
        [Key]
        public decimal? CD_LOG_STATUS { get; set; }
        public decimal? NU_SIGNAL { get; set; }
        public decimal? NU_SPEED { get; set; }
        public DateTime? DT_EVENT { get; set; }
        public decimal? NU_X { get; set; }
        public decimal? NU_Y { get; set; }
    }

    [Table("sm_view_states", Schema = "SMO")]
    public class sm_view_states
    {
        [Key]
        public decimal? CD_EQT_STATE { get; set; }
        public string? NM_SHORT { get; set; }

        public decimal? CD_STATE_1 { get; set; }
        public decimal? CD_STATE_2 { get; set; }
        public decimal? CD_STATE_3 { get; set; }
    }

    [Table("sm_eqt_images", Schema = "SMO")]
    public class sm_eqt_images
    {
        [Key]
        public decimal? CD_EQT_IMAGE { get; set; }
        public string? BL_IMAGE { get; set; }
    }

    [Table("SM_MODEL_EQT", Schema = "SMO")]
    public class sm_model_eqt
    {
        [Key]
        public decimal? CD_MODEL_EQT { get; set; }
        public string? NM_MODEL { get; set; }
        public decimal? CD_GROUP_IMAGE { get; set; }
    }

    public class EquipmentStatus
    {
        public string? EQUIPAMENTO { get; set; }

        public decimal? NUM_ESTADO {  get; set; }
        public string? ESTADO { get; set; }
        public decimal? LATITUDE { get; set; }
        public decimal? LONGITUDE { get; set; }
        public decimal? VELOCIDADE { get; set; }
        public decimal? SINAL { get; set; }
        public decimal? CH_SMT_ACTIVE { get; set; }
        public DateTime? DATA_DO_ESTADO { get; set; }

        public string? TIPO_EQUIPAMENTO { get; set; }
    }

    public class EquipmentAllocationDto
    {
        public decimal CD_EQT { get; set; }
        public DateTime DT_START { get; set; }
        public DateTime DT_END { get; set; }
        public decimal? CD_LOAD { get; set; }
        public decimal? CD_UNLOAD { get; set; }
        public string NM_EQT { get; set; }
        public string MODELO { get; set; }
        public string LOCAL { get; set; }
        public string TIPO_EQUIPAMENTO { get; set; }
    }


    //consultas personalizadas - EQPMENT

    public class EquipmentTransportDto
    {
        public int QTD { get; set; }
        public string? TIPO { get; set; }
    }

    public class EquipamentoAuxiliarDto
    {
        public int QTD { get; set; }
        public string? TIPO { get; set; }
    }

    public class EquipamentoCargaDto
    {
        public int QTD { get; set; }
        public string? TIPO { get; set; }
    }

    public class EquipamentoManutencaoDto
    {
        public int QTD { get; set; }
        public string? TIPO { get; set; }
    }

    //Metodo Alocações - SGND FILEIRA
    public class AlocacaoOrigemDto
    {
        public string NM_ENTITY { get; set; }
        public int QTD { get; set; }
    }

    public class AlocacaoDestinoDto
    {
        public string NM_ENTITY { get; set; }
        public int QTD { get; set; }
    }

    public class AlocacaoMaquinaDto
    {
        public string NM_EQT { get; set; }
        public int QTD { get; set; }
    }


}
